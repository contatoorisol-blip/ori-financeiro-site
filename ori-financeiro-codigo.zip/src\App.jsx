import { siteConfig, getFilledPercent, getRemainingSpots, getWhatsappUrl } from "./siteConfig.js";

const pains = [
  {
    number: "01",
    title: "Caixa no escuro",
    text: "Voce olha para o extrato e nao sabe se o saldo e dinheiro livre ou conta que ainda vai vencer.",
  },
  {
    number: "02",
    title: "Planilha abandonada",
    text: "A planilha ate comeca bonita, mas para na segunda semana. O ORI organiza o dado para virar decisao.",
  },
  {
    number: "03",
    title: "Decisao sem base",
    text: "Contratar, investir ou dar desconto vira aposta quando os numeros do mes nao estao claros.",
  },
];

const advantages = [
  "Online - Pode acessar do celular, do computador ou do tablet.",
  "Ponto de equilibrio em tempo real para saber quanto precisa faturar.",
  "Fluxo de caixa e DRE lado a lado para nao misturar leitura de dinheiro com competencia.",
  "Score ORI para acompanhar a saude financeira sem virar especialista.",
  "Importacao OFX e CSV para revisar lancamentos sem depender de planilha solta.",
];

const entryModes = [
  "1 - Somente app",
  "2 - App + Estruturacao financeira",
];

const featurePanels = [
  {
    title: "Diagnostico do negocio",
    text: "Onde devo melhorar para tomar decisoes com mais clareza.",
  },
  {
    title: "Dashboard completo",
    text: "Fluxo de caixa, DRE e indicadores no mesmo painel.",
  },
  {
    title: "Score de saude",
    text: "Um numero claro para enxergar melhora ou alerta no negocio.",
  },
  {
    title: "Saude Financeira",
    text: "Veja rapidamente se o negocio esta em equilibrio ou pedindo atencao.",
  },
];

const heroHighlights = [
  {
    label: "Resultado projetado",
    value: "R$ 2.301",
    tone: "gold",
  },
  {
    label: "Score ORI",
    value: "72/100",
    tone: "green",
  },
  {
    label: "Margem liquida",
    value: "47,0%",
    tone: "blue",
  },
  {
    label: "Ponto de equilibrio",
    value: "R$ 2.713",
    tone: "gold",
  },
];

const testimonial = {
  quote:
    "Finalmente entendi a diferenca entre caixa e competencia. Agora eu consigo olhar os numeros da agencia e saber o que fazer com eles.",
  name: "Marcella S.",
  role: "Socia-fundadora, Agencia Digital",
};

const faq = [
  {
    question: "Precisa entender de contabilidade?",
    answer:
      "Nao. O ORI foi pensado para empresarios e prestadores de servico. As telas traduzem o numero em decisao pratica.",
  },
  {
    question: "Como funciona a implementacao?",
    answer:
      "Voce chama no WhatsApp, recebe a demonstracao e combinamos os primeiros passos para configurar o uso do ORI no seu negocio.",
  },
  {
    question: "Meus dados ficam seguros?",
    answer:
      "O ORI usa acesso individual e nao pede conexao direta com sua conta bancaria. Voce importa os arquivos que o proprio banco gera.",
  },
  {
    question: "Posso cancelar depois?",
    answer:
      "Sim. A proposta e mensal e sem burocracia. Os detalhes da contratacao sao alinhados na conversa antes de voce entrar.",
  },
];

function Icon({ name }) {
  const paths = {
    bolt: "M13 3 4 14h7l-1 7 9-11h-7l1-7Z",
    check: "M5 13l4 4L19 7",
  };

  return (
    <svg aria-hidden="true" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.2" strokeLinecap="round" strokeLinejoin="round">
      <path d={paths[name]} />
    </svg>
  );
}

function PrimaryCta({ children, className = "" }) {
  return (
    <a className={`btn btn-primary ${className}`.trim()} href={getWhatsappUrl()} target="_blank" rel="noreferrer">
      <Icon name="bolt" />
      {children}
    </a>
  );
}

function FeaturePanel({ title, text }) {
  return (
    <article className="feature-panel">
      <div className="feature-panel-badge" aria-hidden="true">
        <Icon name="check" />
      </div>
      <h3>{title}</h3>
      <p>{text}</p>
    </article>
  );
}

export default function App() {
  const remainingSpots = getRemainingSpots();
  const filledPercent = getFilledPercent();

  return (
    <>
      <nav className="nav">
        <a className="nav-logo" href="#top" aria-label="Voltar ao inicio">
          ORI<span> Financeiro</span>
        </a>
        <div className="nav-actions">
          <a className="nav-link" href={siteConfig.appUrl} target="_blank" rel="noreferrer">
            Ver o sistema
          </a>
          <a className="nav-cta" href={getWhatsappUrl()} target="_blank" rel="noreferrer">
            Quero acesso
          </a>
        </div>
      </nav>

      <main id="top">
        <section className="hero hero-photo-layout">
          <div className="hero-copy">
            <div className="hero-badge">
              <span />
              Acesso antecipado . Preco de lancamento
            </div>
            <h1>
              Sua empresa finalmente <em>sabe para onde</em> o dinheiro vai
            </h1>
            <p>
              O ORI transforma o caos financeiro do seu negocio em clareza total, com demonstracao do sistema e entrada mais leve para quem quer sair da planilha.
            </p>
            <div className="hero-price">
              <span>{siteConfig.oldPrice}</span>
              <strong>
                {siteConfig.price}
                <small>{siteConfig.pricePeriod}</small>
              </strong>
            </div>
            <div className="hero-actions">
              <PrimaryCta>Chamar no WhatsApp e ver a demonstracao</PrimaryCta>
              <a className="btn btn-secondary" href={siteConfig.appUrl} target="_blank" rel="noreferrer">
                Ver o sistema
              </a>
            </div>
            <div className="entry-modes">
              {entryModes.map((mode) => (
                <div className="entry-mode" key={mode}>
                  {mode}
                </div>
              ))}
            </div>
          </div>
          <div className="hero-visual">
            <div className="hero-highlight-board">
              <div className="hero-highlight-header">
                <span>Painel ORI</span>
                <strong>Clareza visual para decidir o mes</strong>
              </div>
              <div className="hero-highlight-grid">
                {heroHighlights.map((item) => (
                  <article className={`hero-highlight-card tone-${item.tone}`} key={item.label}>
                    <small>{item.label}</small>
                    <strong>{item.value}</strong>
                  </article>
                ))}
              </div>
              <div className="hero-highlight-bars" aria-hidden="true">
                <i className="tone-gold" style={{ width: "88%" }} />
                <i className="tone-green" style={{ width: "64%" }} />
                <i className="tone-blue" style={{ width: "94%" }} />
              </div>
              <div className="hero-highlight-note">
                <b>Entrada leve:</b> comece so com o app ou entre com app + estruturacao financeira.
              </div>
            </div>
          </div>
        </section>

        <section className="scarcity" aria-label="Vagas de lancamento">
          <div className="scarcity-copy">
            Preco promocional para os primeiros <strong>{siteConfig.scarcity.totalSpots} usuarios</strong>. Restam <strong>{remainingSpots} vagas</strong>.
          </div>
          <div className="scarcity-meter">
            <span>
              <small>Vagas preenchidas</small>
              <small>
                {siteConfig.scarcity.filledSpots} de {siteConfig.scarcity.totalSpots}
              </small>
            </span>
            <div>
              <i style={{ width: `${filledPercent}%` }} />
            </div>
          </div>
        </section>

        <section className="band">
          <div className="section-head">
            <span>O problema que voce vive hoje</span>
            <h2>
              Voce fatura, mas nunca sabe se esta <em>sobrando</em> ou devendo
            </h2>
            <p>A maioria dos pequenos negocios gere o financeiro no improviso. Improviso em financas vira prejuizo silencioso.</p>
          </div>
          <div className="cards cards-three">
            {pains.map((pain) => (
              <article className={`pain-card${pain.number === "03" ? " pain-card-accent" : ""}`} key={pain.title}>
                <b>{pain.number}</b>
                <h3>{pain.title}</h3>
                <p>{pain.text}</p>
              </article>
            ))}
          </div>
        </section>

        <section className="advantage-section">
          <div className="advantage-visual">
            <img className="advantage-image" src="/assets/ori-devices.png" alt="ORI Financeiro exibido em tablet e celular" />
          </div>
          <div className="advantage-copy">
            <span className="section-kicker">Vantagens ORI</span>
            <h2>
              Tudo que voce precisa <em>sem o que voce nao quer</em>
            </h2>
            <ul className="check-list">
              {advantages.map((item) => (
                <li key={item}>
                  <Icon name="check" />
                  {item}
                </li>
              ))}
            </ul>
            <PrimaryCta className="advantage-cta">Comecar agora</PrimaryCta>
          </div>
        </section>

        <section>
          <div className="section-head">
            <span>Funcionalidades</span>
            <h2>
              Veja como o ORI <em>aparece na pratica</em>
            </h2>
          </div>
          <div className="feature-showcase">
            <div className="feature-phone-wrap">
              <img className="feature-phone" src="/assets/ori-phone.png" alt="Tela do celular com o ORI Financeiro" />
            </div>
            <div className="feature-panel-list">
              {featurePanels.map((item) => (
                <FeaturePanel key={item.title} {...item} />
              ))}
            </div>
          </div>
        </section>

        <section className="band">
          <div className="section-head">
            <span>Quem ja esta usando</span>
            <h2>
              Clareza que faz sentido para quem <em>precisa decidir rapido</em>
            </h2>
          </div>
          <article className="quote-card">
            <div className="quote-mark">"</div>
            <p>{testimonial.quote}</p>
            <div className="quote-author">
              <strong>{testimonial.name}</strong>
              <small>{testimonial.role}</small>
            </div>
          </article>
        </section>

        <section className="pricing" id="preco">
          <div className="pricing-copy">
            <span className="section-kicker">A oferta</span>
            <h2>
              Menos que um lanche por mes para <em>saber onde seu dinheiro vai</em>
            </h2>
            <p>
              {siteConfig.price} por mes para acompanhar caixa, DRE, cartoes, ponto de equilibrio e diagnostico ORI sem depender de planilha solta.
            </p>
            <ul className="check-list">
              <li>
                <Icon name="check" />
                Dashboard com Fluxo de Caixa e DRE
              </li>
              <li>
                <Icon name="check" />
                Ponto de equilibrio automatico
              </li>
              <li>
                <Icon name="check" />
                Score de Saude Financeira
              </li>
              <li>
                <Icon name="check" />
                Importacao de extrato OFX e CSV
              </li>
              <li>
                <Icon name="check" />
                Demonstracao e implementacao pelo WhatsApp
              </li>
            </ul>
          </div>
          <aside className="price-card" aria-label="Preco do ORI Financeiro">
            <span className="price-badge">Preco de lancamento</span>
            <s>De {siteConfig.oldPrice}</s>
            <div className="price-main">
              <strong>{siteConfig.price}</strong>
              <small>{siteConfig.pricePeriod}</small>
            </div>
            <p>Mensalidade do app. A demonstracao e os proximos passos sao alinhados no WhatsApp antes do acesso.</p>
            <PrimaryCta className="price-button">Quero acesso pelo WhatsApp</PrimaryCta>
            <a className="app-link" href={siteConfig.appUrl} target="_blank" rel="noreferrer">
              Ver o sistema antes de chamar
            </a>
            <hr />
            <ul className="include-list">
              <li>
                <Icon name="check" />
                Todas as funcionalidades do ORI
              </li>
              <li>
                <Icon name="check" />
                Atualizacoes inclusas
              </li>
              <li>
                <Icon name="check" />
                Suporte inicial via WhatsApp
              </li>
            </ul>
          </aside>
        </section>

        <section className="faq">
          <div className="section-head centered">
            <span>Perguntas frequentes</span>
            <h2>
              Tire a duvida agora, <em>decida com clareza</em>
            </h2>
          </div>
          <div className="faq-list">
            {faq.map((item, index) => (
              <details key={item.question} open={index === 0}>
                <summary>{item.question}</summary>
                <p>{item.answer}</p>
              </details>
            ))}
          </div>
        </section>

        <section className="final-cta">
          <span className="section-kicker">Ultima chamada</span>
          <h2>
            O dinheiro que some todo mes tem <em>endereco</em>. O ORI ajuda voce a encontrar.
          </h2>
          <p>
            {siteConfig.scarcity.filledSpots} usuarios ja entraram na lista de lancamento. Restam {remainingSpots} vagas no preco promocional.
          </p>
          <PrimaryCta>
            Chamar no WhatsApp - {siteConfig.price}
            {siteConfig.pricePeriod}
          </PrimaryCta>
        </section>
      </main>

      <footer>
        <strong>ORI</strong>
        <span>© 2026 ORI Inteligencia Financeira . Salvador, Bahia</span>
        <a href={siteConfig.appUrl} target="_blank" rel="noreferrer">
          Ver sistema
        </a>
      </footer>
    </>
  );
}
