export const siteConfig = {
  brand: "ORI Financeiro",
  appName: "ORI",
  oldPrice: "R$ 97,00/mês",
  price: "R$ 39,90",
  pricePeriod: "/mês",
  whatsappNumber: "5571993504818",
  whatsappDisplay: "71 99350-4818",
  appUrl: "https://ori-clareza-financeira.vercel.app/",
  scarcity: {
    totalSpots: 100,
    filledSpots: 68,
  },
  whatsappMessage:
    "Oi, quero acessar o ORI Financeiro por R$ 39,90/mês e entender como funciona a implementação e a demonstração do sistema.",
};

export function getWhatsappUrl() {
  return `https://wa.me/${siteConfig.whatsappNumber}?text=${encodeURIComponent(siteConfig.whatsappMessage)}`;
}

export function getRemainingSpots() {
  return Math.max(siteConfig.scarcity.totalSpots - siteConfig.scarcity.filledSpots, 0);
}

export function getFilledPercent() {
  const { totalSpots, filledSpots } = siteConfig.scarcity;
  if (!totalSpots) return 0;
  return Math.min(Math.round((filledSpots / totalSpots) * 100), 100);
}
